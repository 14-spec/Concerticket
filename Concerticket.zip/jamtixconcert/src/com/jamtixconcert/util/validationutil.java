/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jamtixconcert.util;
import java.util.regex.Pattern;
import java.util.HashSet;
/**
 *
 * @author DELL
 */
public class validationutil {

     // Simulated database for account existence checks
    private static final HashSet<String> registeredPhoneNumbers = new HashSet<>();

    // Regular expression patterns
    private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z\\s]+$"); // Alphabets and spaces
    private static final Pattern PHONE_PATTERN = Pattern.compile("^98\\d{8}$");    // Nepal phone numbers starting with 98
    private static final Pattern PRICE_PATTERN = Pattern.compile("^\\d+(\\.\\d{1,2})?$"); // Price in numeric format (e.g., 100, 100.50)
    private static final Pattern TICKET_ID_PATTERN = Pattern.compile("^T\\d{5}$"); // Ticket ID format (e.g., T12345)
    private static final Pattern PAYMENT_STATUS_PATTERN = Pattern.compile("^(Paid|Pending|Failed)$", Pattern.CASE_INSENSITIVE); // Payment statuses

    /**
     * Validates if a string is null or empty.
     *
     * @param value the string to validate
     * @return true if the string is null or empty, otherwise false
     */
    public static boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    /**
     * Validates if the name contains only alphabets and spaces.
     *
     * @param name the name to validate
     * @return true if valid, otherwise false
     */
    public static boolean isValidName(String name) {
        return !isNullOrEmpty(name) && NAME_PATTERN.matcher(name).matches();
    }

    /**
     * Validates if the phone number starts with 98 and has 10 digits in total.
     *
     * @param phone the phone number to validate
     * @return true if valid, otherwise false
     * @throws IllegalArgumentException if the phone number already exists
     */
    public static boolean isValidPhone(String phone) throws IllegalArgumentException {
        if (isNullOrEmpty(phone) || !PHONE_PATTERN.matcher(phone).matches()) {
            return false;
        }
        if (registeredPhoneNumbers.contains(phone)) {
            throw new IllegalArgumentException("Phone number already registered.");
        }
        return true;
    }

    /**
     * Validates if the ticket price is in a valid numeric format.
     *
     * @param priceText the ticket price in text format
     * @return true if valid, otherwise false
     */
    public static boolean isValidPrice(String priceText) {
        return !isNullOrEmpty(priceText) && PRICE_PATTERN.matcher(priceText).matches();
    }

    /**
     * Validates if the ticket ID matches the pattern (e.g., T12345).
     *
     * @param ticketId the ticket ID to validate
     * @return true if valid, otherwise false
     */
    public static boolean isValidTicketId(String ticketId) {
        return !isNullOrEmpty(ticketId) && TICKET_ID_PATTERN.matcher(ticketId).matches();
    }

    /**
     * Validates if the payment status is one of the allowed values.
     *
     * @param paymentStatus the payment status to validate
     * @return true if valid, otherwise false
     */
    public static boolean isValidPaymentStatus(String paymentStatus) {
        return !isNullOrEmpty(paymentStatus) && PAYMENT_STATUS_PATTERN.matcher(paymentStatus).matches();
    }

    /**
     * Validates all fields in one place for a ticket.
     *
     * @param name          the attendee's name
     * @param phone         the attendee's phone number
     * @param price         the ticket price
     * @param ticketId      the ticket ID
     * @param paymentStatus the payment status
     * @return true if all fields are valid, otherwise false
     * @throws IllegalArgumentException for duplicate phone numbers
     */
    public static boolean validateAllFields(String name, String phone, String price, String ticketId, String paymentStatus) throws IllegalArgumentException {
        return isValidName(name)
                && isValidPhone(phone) // Throws exception if duplicate phone is found
                && isValidPrice(price)
                && isValidTicketId(ticketId)
                && isValidPaymentStatus(paymentStatus);
    }

    /**
     * Registers a phone number after validation to simulate account creation.
     *
     * @param phone the phone number to register
     * @throws IllegalArgumentException if the phone number is invalid or already exists
     */
    public static void registerPhoneNumber(String phone) throws IllegalArgumentException {
        if (!isValidPhone(phone)) {
            throw new IllegalArgumentException("Invalid phone number.");
        }
        registeredPhoneNumbers.add(phone);
    }

    /**
     * Utility method to gracefully handle exceptions during validation.
     *
     * @param runnable the operation to execute
     */
    public static void handleValidation(Runnable runnable) {
        try {
            runnable.run();
        } catch (IllegalArgumentException e) {
            System.err.println("Validation Error: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected Error: " + e.getMessage());
        }
    }
}

    

