/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jamtixconcert.controlleralgorithm;
import com.jamtixconcert.model.ticketmodel;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author DELL
 */
public class selectionsort {
    private final List<ticketmodel> ticketsortList; // List to hold ticketmodel objects

    public selectionsort() {
        ticketsortList = new ArrayList<>();
    }

    /**
     * Sorts a list of ticketmodel objects by their ticket ID in ascending or
     * descending order.
     *
     * @param ticketList the list of ticketmodel objects to be sorted
     * @param isDesc specifies the sort order (true for descending, false for
     *               ascending)
     * @return the sorted list of ticketmodel objects
     * @throws IllegalArgumentException if the ticket list is null or empty
     */
    public List<ticketmodel> sortByTicketId(List<ticketmodel> ticketList, boolean isDesc) {
        this.ticketsortList.clear();
        this.ticketsortList.addAll(ticketList);

        // Check for null or empty list
        if (ticketsortList == null || ticketsortList.isEmpty()) {
            throw new IllegalArgumentException("Ticket list cannot be null or empty.");
        }

        // Selection sort algorithm
        for (int i = 0; i < ticketsortList.size() - 1; i++) {
            int extremumIndex = findExtremumIndex(ticketsortList, i, isDesc);
            if (i != extremumIndex) {
                swap(ticketsortList, i, extremumIndex);
            }
        }

        return ticketsortList;
    }

    /**
     * Finds the index of the extremum value (minimum or maximum) in the list
     * from the start index.
     *
     * @param ticketSortList the list of ticketmodel objects
     * @param startIndex the index to start searching from
     * @param isDesc specifies whether to find the maximum (true) or minimum
     *               (false)
     * @return the index of the extremum value
     */
    private int findExtremumIndex(List<ticketmodel> ticketSortList, int startIndex, boolean isDesc) {
        int extremumIndex = startIndex;

        // Compare all subsequent elements to find the extremum
        for (int j = startIndex + 1; j < ticketSortList.size(); j++) {
            // Get the IDs of the current and extremum ticket models
            int currentId = Integer.parseInt(ticketSortList.get(j).getid()); // Convert to integer for numerical comparison
            int extremumId = Integer.parseInt(ticketSortList.get(extremumIndex).getid()); // Convert to integer

            // Check if we need to swap based on sorting order (ascending or descending)
            if (shouldSwap(currentId, extremumId, isDesc)) {
                extremumIndex = j;
            }
        }

        return extremumIndex;
    }

    /**
     * Determines whether the current value should replace the current extremum
     * based on sort order.
     *
     * @param current the current ticket ID value
     * @param extremum the current extremum ticket ID value
     * @param isDesc specifies the sort order (true for descending, false for
     *               ascending)
     * @return true if the current value should replace the extremum; false otherwise
     */
    private boolean shouldSwap(int current, int extremum, boolean isDesc) {
        return isDesc ? current > extremum : current < extremum;
    }

    /**
     * Swaps two elements in the list.
     *
     * @param ticketSortList the list of ticketmodel objects
     * @param i the index of the first element
     * @param j the index of the second element
     */
    private void swap(List<ticketmodel> ticketSortList, int i, int j) {
        ticketmodel temp = ticketSortList.get(i);
        ticketSortList.set(i, ticketSortList.get(j));
        ticketSortList.set(j, temp);
    }
    
}
