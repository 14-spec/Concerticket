/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jamtixconcert.model;

/**
 *
 * @author DELL
 */
public class ticketmodel { 
     private String name; // Attendee's name
     private String phone;// Attendee's Phone number
     private double price;// Ticket price 
     private String id;   // Ticket identification number
     private String payment; // Payment status

    // Default constructor
    public ticketmodel() {
    }

    // Parameterized constructor

    /**
     *
     * @param name
     * @param phone
     * @param price
     * @param id
     * @param payment
     */
    public ticketmodel(String name, String phone, String id, double price, String payment) {
        this.name = name;
        this.phone = phone;
        this.price = price;
        this.id = id;
        this.payment = payment;
    }

    // Getters and Setters
    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getphone() {
        return phone;
    }

    public void setphone(String phone) {
        this.phone = phone;
    }

    public double getprice() {
        return price;
    }

    public void setprice(double price) {
        this.price = price;
    }

    public String getid() {
        return id;
    }

    public void setid(String id) {
        this.id = id;
    }

    public String getpayment() {
        return payment;
    }

    /**
     *
     * @param payment
     */
    public void setpayment(String payment) {
        this.payment = payment;
    }
}
